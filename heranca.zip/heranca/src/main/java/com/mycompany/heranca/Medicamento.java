/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.heranca;

/**
 *
 * @author User
 */
public class Medicamento extends Produto
{
    private String princAtivo;
    boolean TarjaPreta;
    
public Medicamento(String descricao, float preco, String princAtivo, boolean TarjaPreta) 
        {
		super(descricao, preco);
		this.princAtivo = princAtivo;
		this.TarjaPreta = TarjaPreta;
	}

@Override
	public void aumento(float valor) 
        {
		super.aumento(valor);
                super.setPreco(super.getPreco() + (getPreco() * 0.10f));
	}

    public String getPrincAtivo() {
        return princAtivo;
    }

    public void setPrincAtivo(String princAtivo) {
        this.princAtivo = princAtivo;
    }

    public boolean isTarjaPreta() {
        return TarjaPreta;
    }

    public void setTarjaPreta(boolean TarjaPreta) {
        this.TarjaPreta = TarjaPreta;
    }
    
    
    
    
}


