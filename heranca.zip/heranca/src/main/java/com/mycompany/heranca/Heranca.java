/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.heranca;

/**
 *
 * @author User
 */

import java.text.DecimalFormat;
import java.util.Scanner;
public class Heranca {

    public static void main(String[] args) 
    {
        // Instancia os objetos
	    //Medicamento remedinho = new Medicamento("Viagra", 12.00f, "Citrato de Sildenafila", false);
	    //Higiene higi = new Higiene("Soro fisiológico", 5.75f, "Limpeza das vias nasais");
	    // Formatação dos valores float
	    DecimalFormat df = new DecimalFormat("#.00");
            
           Scanner scanner = new Scanner(System.in);

        System.out.print("Digite o nome do medicamento: ");
        String nomeMedicamento = scanner.nextLine().trim();

        System.out.print("Digite o preço do medicamento: ");
        float precoMedicamento = scanner.nextFloat();
        scanner.nextLine(); // Limpa o buffer após nextFloat

        System.out.print("Digite o nome químico do medicamento: ");
        String princAtivo = scanner.nextLine().trim();

        System.out.print("É tarja preta? (true/false): ");
        boolean tarjaPreta = scanner.nextBoolean();
        scanner.nextLine(); // Limpa o buffer após nextBoolean
        
        System.out.print("-----------------------------------------\n");

        System.out.print("Agora digite o nome do produto higiênico: ");
        String nomeHigi = scanner.nextLine().trim();

        System.out.print("Digite o preço do produto higiênico: ");
        float precoHigi = scanner.nextFloat(); 
        scanner.nextLine();// Limpa o buffer após nextFloat
        
        System.out.print("Em qual parte do corpo o produto deve ser usado? ");
        String corpoHigi = scanner.nextLine().trim();
 
        
        Medicamento remedinho = new Medicamento(nomeMedicamento, precoMedicamento, princAtivo, tarjaPreta);
        
        Higiene higi = new Higiene(nomeHigi, precoHigi, corpoHigi);
        
        // Aplica aumento de preço
        System.out.print("Digite o acréscimo inflacionário no preço do medicamento: ");
        float aumentoMedicamento = scanner.nextFloat();
        remedinho.aumento(aumentoMedicamento);

        System.out.print("Digite o acréscimo inflacionário no preço do produto de higiene: ");
        float aumentoProduto = scanner.nextFloat();
        higi.aumento(aumentoProduto);     

        // Exibe os resultados
        System.out.println("\nResultado:");
        System.out.println("\nMedicamento:");
        System.out.println("Produto: " + remedinho.getDescricao());
        System.out.println("Preço: " + df.format(remedinho.getPreco()));
        System.out.println("Nome químico: " + remedinho.getPrincAtivo());
        System.out.println("É tarja preta: " + remedinho.isTarjaPreta());
        System.out.println("------------------------------");
        System.out.println("Produto higiênico: " + higi.getDescricao());
        System.out.println("Preço: " + df.format(higi.getPreco()));
        System.out.println("Parte do corpo para uso: " + higi.getUso());
        scanner.close();
    }    
}
